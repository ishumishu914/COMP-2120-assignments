public class CustomerClassDemo 
{
    public static void main(String[] args) 
    {
        Customer customer = new Customer("Julie James", "123 Main Street", "555-1212", "147-A049", true);
        System.out.println(customer.toString());  
    }    
}
