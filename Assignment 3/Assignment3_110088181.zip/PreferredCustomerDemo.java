public class PreferredCustomerDemo 
{
    public static void main(String[] args) 
    {
        PreferredCustomer specialCustomer = new PreferredCustomer("Julie James", "123 Main Street", "555-1212", "147-A049", true, 1750.00);
        System.out.println(specialCustomer.toString());    
    }    
}
