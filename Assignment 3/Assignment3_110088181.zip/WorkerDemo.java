public class WorkerDemo 
{
    public static void main(String[] args) 
    {
        ProductionWorker[] worker = new ProductionWorker[]{
            new ProductionWorker("John Smith", "123-A", "11-15-2005", 1, 16.50),
            new ProductionWorker("Joan Jones", "222-L", "12-12-2005", 2, 18.50)
        };
        
        System.out.println("\nHere's the first production worker.");
        System.out.println(worker[0].toString());

        System.out.println("\nHere's the second production worker.");
        System.out.println(worker[1].toString());
    }
}
